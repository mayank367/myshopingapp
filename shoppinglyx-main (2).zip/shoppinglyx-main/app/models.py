from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxLengthValidator, MinLengthValidator 

STATE_CHOICE =(
    ("Andhra Pradesh","Andhra Pradesh"),
    ("Arunachal Pradesh","Arunachal Pradesh"),
    ("Assam","Assam"),
    ("Bihar","Bihar"),
    ("Chhattisgarh","Chhattisgarh"),
    ("Goa","Goa"),
    ("Gujarat","Gujarat"),
    ("Haryana","Haryana"),
    ("Himachal Pradesh","Himachal Pradesh"),
    ("Jharkhand","Jharkhand"),
    ("Karnataka","Karnataka"),
    ("Kerala","Kerala"),
    ("Madhya Pradesh","Madhya Pradesh"),
    ("Maharashtra","Maharashtra"),
    ("Manipur","Manipur"),
    ("Meghalaya","Meghalaya"),
    ("Mizoram","Mizoram"),
    ("Nagaland","Nagaland"),
    ("Odisha","Odisha"),
    ("Punjab","Punjab"),
    ("Rajasthan","Rajasthan"),
    ("Sikkim","Sikkim"),
    ("Tamil Nadu","Tamil Nadu"),
    ("Telangana","Telangana"),
    ("Tripura","Tripura"),
    ("Uttar Pradesh","Uttar Pradesh"),
    ("Uttarakhand","Uttarakhand"),
    ("West Bengal","West Bengal")
)
class Customer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=150)
    locality = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    zipcode= models.IntegerField()
    state = models.CharField(max_length=50, choices= STATE_CHOICE)
    

CATEGOGRY_CHOICE =(
    ('m','mobile'),
    ('l','laptop'),
    ('tw','top wear'),
    ('w', 'watch'),
    ('bw','bottomwear'),
    ('fc','fullcombo')

)

COLOR_CHOICES = [
        ('black', 'black'),
        ('white', 'white'),
        ('sky', 'sky'),
        ('pink', 'pink'),
        ('green', 'green'),
        ('multi','multi')
]
class Product(models.Model):
    title =models.CharField(max_length=100)   
    selling_price =models.FloatField()
    discount_price =models.FloatField()
    description =models.TextField()
    brand = models.CharField(max_length=100)
    category = models.CharField(choices=CATEGOGRY_CHOICE, max_length=2)
    Product_image = models.ImageField(upload_to='productimg') 
    color = models.CharField(max_length=5, choices=COLOR_CHOICES)



STATE_CHOICE= (
    ('Accepted','Accepted'),
    ('packed','packed'),
    ('one the way','one the way'),
    ('Delivered','Delivered'),
    ('Cancel', 'Cancel')
)


class Cart(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product =models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity =models.PositiveIntegerField(default=1)


class Orderplaced(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    customer =models.ForeignKey(Customer,on_delete=models.CASCADE)
    product =models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity =models.PositiveIntegerField(default=1)
    ordered_date =models.DateTimeField(auto_now_add=True)
    status =models.CharField(max_length=50,choices=STATE_CHOICE,default='pending')


