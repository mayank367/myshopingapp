from django.contrib import messages
from django.shortcuts import render
from django.views import View
from .forms import CustomerRegistrationForm, LoginForm
from django.contrib.auth.views import LoginView


from .models import Product

# def home(request):
#  return render(request, 'app/home.html')

class ProductView(View):
 def get(self,request):
  topwear = Product.objects.filter(category='tw')
  mobile = Product.objects.filter(category='m')
  watch = Product.objects.filter(category='w')
  bottomwear = Product.objects.filter(category='bw')
  fullcombo = Product.objects.filter(category='fc')


  return render(request,'app/home.html',{'topwear':topwear,'mobile':mobile,'watch':watch , 'bottomwear':bottomwear,'fullcombo':fullcombo})


 

# def product_detail(request):
#  return render(request, 'app/productdetail.html')

class ProductDetailView(View):
 def get(self,request,pk):
  product = Product.objects.get(pk=pk)
  return render (request,'app/productdetail.html',{'product':product})


# class AddToCartView(View):
#  def get(self,request,pk):
#   product = Product.objects.get(pk=pk)
#   return render (request,'app/addtocart.html',{'product':product})
# #  return render(request, 'app/addtocart.html')

def add_to_cart(request):
 return render(request, 'app/addtocart.html')

def buy_now(request):
 return render(request, 'app/buynow.html')

def profile(request):
 return render(request, 'app/profile.html')

def address(request):
 return render(request, 'app/address.html')

def orders(request):
 return render(request, 'app/orders.html')

def change_password(request):
 return render(request, 'app/changepassword.html')

def mobile(request, data=None):
  if data ==None:
    mobiles = Product.objects.filter(category='m')
  elif data == 'vivo'or data =='oneplus'  or data == 'iphone':
   mobiles = Product.objects.filter(category='m').filter(brand=data)
  elif data == 'below':
   mobiles = Product.objects.filter(category='m').filter(discount_price__lt=10000)
  elif data == 'above':
   mobiles = Product.objects.filter(category='m').filter(discount_price__gt=10000)
  elif data == 'black'or data =='white'  or data == 'sky' or data =='pink' or data =='green':
   mobiles = Product.objects.filter(category='m').filter(color=data)  
  return render(request, 'app/mobile.html',{'mobiles':mobiles})


def watch(request, data=None):
  if data ==None:
   watches = Product.objects.filter(category='w')
  elif data == 'noise'or data =='firebolt'  or data == 'fastrack':
   watches = Product.objects.filter(category='w').filter(brand=data)
  elif data == 'below':
   watches = Product.objects.filter(category='w').filter(discount_price__lt=1500)
  elif data == 'above':
   watches = Product.objects.filter(category='w').filter(discount_price__gt=1500) 
  return render(request, 'app/watch.html',{'watches':watches})

def login(request):
 return render(request, 'app/login.html')

# class LoginView(LoginView):
#     template_name = 'login.html'  
#     form_class = LoginForm

# def customerregistration(request):
#  return render(request, 'app/customerregistration.html')

class CustomerRegistrationView(View):
 def get(self,request):
  form = CustomerRegistrationForm
  return render(request,'app/customerregistration.html',{'form':form})
 def post(self,request):
  form = CustomerRegistrationForm(request.POST)
  if form.is_valid():
   messages.success(request,'Congratulation!! message Send Succesfully!!')
   form.save()
  return render(request,'app/customerregistration.html',
  {'form':form})

# class Login(LoginView):
#     template_name = 'login.html'
#     fields = ['email','password']
#     success_url = 'login_list'


def checkout(request):
 return render(request, 'app/checkout.html')
