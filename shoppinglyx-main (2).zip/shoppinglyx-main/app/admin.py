from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html
from .models import (
    Customer,
    Cart,
    Product,
    Orderplaced
)


@admin.register(Customer)
class CustomerModelAdmin(admin.ModelAdmin):
    list_display=['id','user','name','locality','city','zipcode','state']
    

@admin.register(Product)
class ProductModelAdmin(admin.ModelAdmin):
    list_display =['id','title','selling_price',
                   'discount_price','description',
                   'brand','category','Product_image','view_actions']
    
    def view_actions(self, obj):
        change_url = reverse('admin:app_product_change', args=[obj.pk])
        return format_html(
            '<a class="button" href="{}">Update</a> ',
            change_url
        )
    
    view_actions.short_description = 'Actions'

@admin.register(Cart)
class CartModelAdmin(admin.ModelAdmin):
    list_display=['id','user','product','quantity']


@admin.register(Orderplaced)
class OrderPlaceedModelAdmin(admin.ModelAdmin):
    list_display =['id','user','customer','product','quantity','ordered_date','status']